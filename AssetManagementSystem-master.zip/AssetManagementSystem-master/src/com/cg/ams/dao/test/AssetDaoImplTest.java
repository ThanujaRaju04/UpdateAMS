package com.cg.ams.dao.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.ams.bean.AssetAllocationBean;
import com.cg.ams.bean.AssetsBean;
import com.cg.ams.dao.AssetDaoImpl;
import com.cg.ams.dao.IAssetDao;
import com.cg.ams.exception.AMSException;

public class AssetDaoImplTest {
	IAssetDao dao;

	@Before
	public void setUp() throws Exception {
		dao=new AssetDaoImpl();
				
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
		
	}

	@Test
	public void testGetuserType() throws AMSException {
       String role = dao.getuserType("abcd", "123");
       assertEquals("admin", role);
	}

	@Test
	public void testAllocateAsset() throws AMSException {

		int allocate = dao.allocateAsset(1234, "keyboard");
		assertEquals(100, allocate);
		
	
	
	}

	@Test
	public void testDeallocateAsset() throws AMSException {
		int allocate = dao.deallocateAsset(1235, "monitor");
		assertEquals(98, allocate);
		
	}

	@Test
	public void testInsertDetails() throws AMSException {
	AssetsBean bean =new AssetsBean(123, "keyboard", 12);
	int insert = dao.insertDetails(bean);
	assertEquals(1, insert);
	}

	@Test
	public void testViewRequest() throws AMSException {
		List<AssetAllocationBean> list=dao.viewRequest();
		assertFalse(list.isEmpty());
	}

	/*@Test
	public void testApprove() throws AMSException {
		AssetAllocationBean assetallocation=new AssetAllocationBean(123, "keyboard", 1264, "pending");
		int approve = dao.approve(assetallocation);
		assertEquals(1, approve);
	}*/

	@Test
	public void testViewQuantity() throws AMSException {
	int quantity=dao.viewQuantity("Monitor");
	assertEquals(24, quantity);
	}

	@Test
	public void testDecrementQuantity() throws AMSException {
		int quantity=dao.viewQuantity("keyboard");
		assertEquals(12, quantity);
	}

	@Test
	public void testIncrease() throws AMSException {
       int delete=dao.increase("keyboard");
       assertEquals(1, delete);
	}

	@Test
	public void testIncrementQuantity() throws AMSException {
		 int increase=dao.incrementQuantity("keyboard");
	       assertEquals(0, increase);	
	}

	@Test
	public void testDeleteRequest() throws AMSException {
		int delete=dao.deleteRequest(1234);
		assertEquals(2, delete);
	}

	@Test
	public void testValidAsset() throws AMSException {
		int valid=dao.validAsset("keyboard");
		assertEquals(1, valid);
	}

	@Test
	public void testUpdateAsset() throws AMSException {
		AssetsBean bean=new AssetsBean();
		int update=dao.updateAsset(bean);
		assertEquals(0, update);
	}

}
